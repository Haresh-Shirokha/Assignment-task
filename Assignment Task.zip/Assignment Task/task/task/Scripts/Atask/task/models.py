from django.db import models

# Create your models here.


# from rest_framework import serializers

# # class ConfigurationSerializer(serializers.Serializer):
# #     sym1 = serializers.CharField()
# #     sym2 = serializers.CharField()
# #     sym3 = serializers.CharField()
# #     sym4 = serializers.CharField()
# #     sym5 = serializers.CharField()
# #     sym6 = serializers.CharField()
# #     sym8 = serializers.CharField()
# #     sym0 = serializers.CharField()

# class ConfigurationSerializer(serializers.Serializer):
#     sym1 = serializers.CharField(required=False)
#     sym2 = serializers.CharField(required=False)
#     sym3 = serializers.CharField(required=False)
#     sym4 = serializers.CharField(required=False)  # Make sure this field is optional or remove it if it's not present in all data
#     sym5 = serializers.CharField(required=False)
#     sym6 = serializers.CharField(required=False)
#     sym8 = serializers.CharField(required=False)
#     sym0 = serializers.CharField(required=False)
