

# # from django.shortcuts import render
# # from rest_framework.views import APIView
# # from rest_framework.response import Response
# # from rest_framework import serializers

# # class ConfigurationSerializer(serializers.Serializer):
# #     sym1 = serializers.CharField(required=False)
# #     sym2 = serializers.CharField(required=False)
# #     sym3 = serializers.CharField(required=False)
# #     sym4 = serializers.CharField(required=False)
# #     sym5 = serializers.CharField(required=False)
# #     sym6 = serializers.CharField(required=False)
# #     sym8 = serializers.CharField(required=False)
# #     sym0 = serializers.CharField(required=False)

# # class ConfigurationView(APIView):
# #     def get(self, request, id):
# #         # Replace this logic with your actual configuration retrieval based on id
# #         # Here, I'm providing a static example
# #         if id == "qwertyuiop":
# #             initial_2d_array = [
# #                 {"sym1": "a", "sym2": "b", "sym3": "c"},
# #                 {"sym4": "d", "sym6": "f", "sym8": "h"},
# #                 {"sym5": "e", "sym1": "a", "sym0": "0"}
# #             ]
# #             serializer = ConfigurationSerializer(initial_2d_array, many=True)
# #             return Response(serializer.data, template_name='api.html')
# #         else:
# #             return Response({"error": "Configuration not found"}, status=404)

# # views.py

# # from django.shortcuts import render
# # from rest_framework.views import APIView
# # from rest_framework.response import Response
# # from rest_framework import serializers

# # class ConfigurationSerializer(serializers.Serializer):
# #     sym1 = serializers.CharField(required=False)
# #     sym2 = serializers.CharField(required=False)
# #     sym3 = serializers.CharField(required=False)
# #     sym4 = serializers.CharField(required=False)
# #     sym5 = serializers.CharField(required=False)
# #     sym6 = serializers.CharField(required=False)
# #     sym8 = serializers.CharField(required=False)
# #     sym0 = serializers.CharField(required=False)


# # class ConfigurationView(APIView):
# #     def get(self, request, id=None):
# #         # Default data to display
# #         initial_2d_array = [
# #             {"sym1": "a", "sym2": "b", "sym3": "c"},
# #             {"sym4": "d", "sym6": "f", "sym8": "h"},
# #             {"sym5": "e", "sym1": "a", "sym0": "0"}
# #         ]
        
# #         if id == "qwertyuiop":
# #             # If the ID is qwertyuiop, return the JSON response
# #             serializer = ConfigurationSerializer(initial_2d_array, many=True)
# #             return render(request, 'submit_page.html', {'user_input': id, 'data': serializer.data})
# #         else:
# #             # Otherwise, display the default data
# #             return render(request, 'submit_page.html', {'user_input': None, 'data': None})

# #     def post(self, request, id=None):
# #         # Handle form submission
# #         user_input = request.POST.get('input_field')
# #         return self.get(request, id=user_input)

# # def form(request):
# #     return render(request, 'form_page.html')


# # views.py

# from django.shortcuts import render, redirect
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import serializers

# class ConfigurationSerializer(serializers.Serializer):
#     sym1 = serializers.CharField(required=False)
#     sym2 = serializers.CharField(required=False)
#     sym3 = serializers.CharField(required=False)
#     sym4 = serializers.CharField(required=False)
#     sym5 = serializers.CharField(required=False)
#     sym6 = serializers.CharField(required=False)
#     sym8 = serializers.CharField(required=False)
#     sym0 = serializers.CharField(required=False)

# class ConfigurationView(APIView):
#     def get(self, request, id=None):
#         # Default data to display
#         initial_2d_array = [
#             {"sym1": "a", "sym2": "b", "sym3": "c"},
#             {"sym4": "d", "sym6": "f", "sym8": "h"},
#             {"sym5": "e", "sym1": "a", "sym0": "0"}
#         ]
        
#         if id == "qwertyuiop":
#             # If the ID is qwertyuiop, return the JSON response
#             serializer = ConfigurationSerializer(initial_2d_array, many=True)
#             return render(request, 'submit_page.html', {'user_input': id, 'data': serializer.data})
#         else:
#             # Otherwise, display the default data
#             return render(request, 'submit_page.html', {'user_input': None, 'data': None})

#     def post(self, request, id=None):
#         # Handle form submission
#         user_input = request.POST.get('input_field')
#         return redirect('form', id=user_input)

# def form(request, id=None):
#     # return render(request, 'form_page.html', {'user_input': id})
#     return redirect('form', id='qwertyuiop')



# views.py

from django.shortcuts import render, redirect
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import serializers

class ConfigurationSerializer(serializers.Serializer):
    sym1 = serializers.CharField(required=False)
    sym2 = serializers.CharField(required=False)
    sym3 = serializers.CharField(required=False)
    sym4 = serializers.CharField(required=False)
    sym5 = serializers.CharField(required=False)
    sym6 = serializers.CharField(required=False)
    sym8 = serializers.CharField(required=False)
    sym0 = serializers.CharField(required=False)

class ConfigurationView(APIView):
    def get(self, request, id=None):
        # Default data to display
        initial_2d_array = [
            {"sym1": "a", "sym2": "b", "sym3": "c"},
            {"sym4": "d", "sym6": "f", "sym8": "h"},
            {"sym5": "e", "sym1": "a", "sym0": "0"}
        ]
        
        if id == "qwertyuiop":
            # If the ID is qwertyuiop, return the JSON response
            serializer = ConfigurationSerializer(initial_2d_array, many=True)
            return render(request, 'submit_page.html', {'user_input': id, 'data': serializer.data})
        else:
            # Otherwise, display the default data
            return render(request, 'submit_page.html', {'user_input': None, 'data': None})

    def post(self, request, id=None):
        # Handle form submission
        user_input = request.POST.get('input_field')
        return redirect('get_configuration', id=user_input)  # Update to use 'get_configuration' name

def form(request, id=None):
    return render(request, 'form_page.html', {'user_input': id})
